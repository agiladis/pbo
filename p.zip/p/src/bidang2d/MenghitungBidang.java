/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bidang2d;

/**
 *
 * @author xShido
 */
public interface MenghitungBidang {
    public double luas();
    public double keliling();
}
