/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bidang2d;

/**
 *
 * @author ASUS
 */
public interface Bidang2D {
//    final double r = 0, panjang = 0, lebar = 0, tinggi = 0, keliling = 0, luas = 0;
    double hitungKeliling();  
    double hitungLuas();
}
