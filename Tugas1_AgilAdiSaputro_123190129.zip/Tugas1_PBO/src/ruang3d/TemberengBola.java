/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ruang3d;

/**
 *
 * @author ASUS
 */
public class TemberengBola extends Bola{
    
    public TemberengBola(int r, int keliling, int luas) {
        super(r, keliling, luas);
    }
    
    public double hitungLuas(){
        
    }
    
    public double hitungVolume(){
        
    }
}
